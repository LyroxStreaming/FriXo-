const { ApplicationCommandOptionType, CommandInteraction, Client, EmbedBuilder } = require("discord.js");
const db = require("../../schema/dj");

module.exports = {
    name: "toggledj",
    description: "Toggle Dj role.",
    userPrams: ['ManageGuild'],
    botPrams: ['ManageGuild'],
    vote: true,
    options: [
        {
            name: 'toggledj',
            description: 'Enable Disable Dj Roles.',
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                {
                    name: 'enable',
                    value: `dj_on`,
                },
                {
                    name: 'disable',
                    value: `dj_off`,
                },
            ],
        },
    ],
    /**
    * @param {Client} client
    * @param {CommandInteraction} interaction
    */

    run: async (client, interaction) => {
        let data = await db.findOne({ Guild: interaction.guildId });
        const input = interaction.options.getString('toggledj');

        if(!data) return interaction.reply({embeds:[new EmbedBuilder()
            .setTitle(`<:no:927525488644194345> Don't Have Dj Setup In This Guild`)
            .setColor(client.embedColor)
            .setFooter({text: 'Powered by hydra-hosting.eu'})]});

        if (input === `dj_on`) {
            let mode = false;
            if (!data.Mode) mode = true;
            data.Mode = mode;
            await data.save();
            const thing = new EmbedBuilder()
                .setTitle(`<:yes:927525490443571261> Enabled DJ Mode.`)
                .setColor(client.embedColor)
                .setFooter({text: 'Powered by hydra-hosting.eu'});
            await interaction.reply({ embeds: [thing] });
        }

        if (input === `dj_off`) {
            let mode = true;
            if (data.Mode) mode = false;
            data.Mode = mode;
            await data.save();
            const thing = new EmbedBuilder()
            .setTitle(`<:yes:927525490443571261> Disabled DJ Mode.`)
            .setColor(client.embedColor)
            .setFooter({text: 'Powered by hydra-hosting.eu'});
            return await interaction.reply({ embeds: [thing] });
        };
    },
};