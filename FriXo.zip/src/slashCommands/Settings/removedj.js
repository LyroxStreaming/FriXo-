const { CommandInteraction, Client, EmbedBuilder } = require("discord.js");
const db = require("../../schema/dj");

module.exports = {
    name: "removedj",
    description: "Delete Dj role.",
    userPrams: ['ManageGuild'],
    botPrams: ['ManageGuild'],
    vote: true,
    /**
    * @param {Client} client
    * @param {CommandInteraction} interaction
    */

    run: async (client, interaction) => {
        let data = await db.findOne({ Guild: interaction.guildId });
        if (data) {
            await data.delete();
            return interaction.reply({ embeds: [new EmbedBuilder()
                .setTitle(`<:yes:927525490443571261> Successfully Removed All DJ Roles.`)
                .setColor(client.embedColor)
                .setFooter({text: 'Powered by hydra-hosting.eu'})]});

        } else return interaction.reply({ embeds: [new EmbedBuilder()
            .setTitle(`<:no:927525488644194345> Don't Have Dj Setup In This Guild`)
            .setColor(client.embedColor)
            .setFooter({text: 'Powered by hydra-hosting.eu'})]});
    },
};