const { ApplicationCommandOptionType, EmbedBuilder, CommandInteraction, Client } = require("discord.js");
const db = require("../../schema/playlist");

module.exports = {
  name: 'pl-delete',
  description: 'Delete your saved playlist.',
  usage: '<playlist name>',
  userPrams: [],
  botPrams: ['EmbedLinks'],
  player: false,
  inVoiceChannel: false,
  sameVoiceChannel: false,
  vote: true,
  options: [
    {
      name: 'name',
      description: 'Playlist Name',
      required: true,
      type: ApplicationCommandOptionType.String,
    },
  ],
  /**
   *
   * @param {Client} client
   * @param {CommandInteraction} interaction
   */

  run: async (client, interaction, player) => {
    const Name = interaction.options.getString('name');
    const data = await db.findOne({ UserId: interaction.member.user.id, PlaylistName: Name });
    if (!Name) {
      return interaction.reply({ embeds: [new EmbedBuilder()
          .setColor(client.embedColor)
          .setDescription(`<:no:927525488644194345> You didn't entered a playlist name\nUsage: \`/pl-delete <playlist name>\`\nName Information:\n\`Can be anything with maximum of 10 Letters\``)
          .setFooter({text: 'Powered by hydra-hosting.eu'})]});
  };
  if (!data) {
      return interaction.reply({ embeds: [new EmbedBuilder()
          .setColor(client.embedColor)
          .setTitle(`<:no:927525488644194345> You don't have a playlist with \`${Name}\` name`)] });
  };
  await data.delete();
  const embed = new EmbedBuilder()
      .setColor(client.embedColor)
      .setTitle(`<:yes:927525490443571261> Successfully deleted \`${Name}\` playlist`)
      .setFooter({text: 'Powered by hydra-hosting.eu'});
  return interaction.reply({ embeds: [embed] })
  },
};
