const { EmbedBuilder, CommandInteraction, Client, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  name: 'support',
  description: 'lara support',
  userPrams: [],
  botPrams: ['EmbedLinks'],

  /**
   *
   * @param {Client} client
   * @param {CommandInteraction} interaction
   */

  run: async (client, interaction) => {
    let user = client.user
    let button_support_dc = new ButtonBuilder()
    .setEmoji("<:plus:927525489445318746>")
    .setStyle(ButtonStyle.Link)
    .setLabel('Support Server')
    .setURL("https://discord.gg/xcjZqS9nJY")

    let button_invite = new ButtonBuilder()
    .setEmoji("<:links:927525488681971722>")
    .setStyle(ButtonStyle.Link)
    .setLabel("Invite " + user.username)
    .setURL(`https://discord.com/api/oauth2/authorize?client_id=${user.id}&permissions=8&scope=bot%20applications.commands`)
    
    let butweb = new ButtonBuilder()
    .setEmoji(`<:filters2:950441619444879371>`)
    .setStyle(ButtonStyle.Link)
    .setLabel(`Website`)
    .setURL(`https://larabot.tk`)

  const allbuttons = [new ActionRowBuilder().addComponents([button_support_dc, button_invite, butweb])];
  interaction.reply({
  embeds: [new EmbedBuilder()
    .setColor(client.embedColor)
    .setDescription(`
    __**What we provide**__
    Join support server to get help`)
    .setImage(`https://cdn.discordapp.com/attachments/925414156029538375/992463049350987886/Support.png`)
    .setFooter({text: 'Powered by hydra-hosting.eu'})
    ],
  components: allbuttons 
    });
  },
};
