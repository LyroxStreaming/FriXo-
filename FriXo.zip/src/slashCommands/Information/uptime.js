const { EmbedBuilder, CommandInteraction, Client } = require("discord.js");
const { duration } = require('../../utils/functions');

module.exports = {
    name: "uptime",
    description: "Update on lara",
    userPrams: [],
    botPrams: ['EmbedLinks'],

    /**
   * 
   * @param {Client} client 
   * @param {CommandInteraction} interaction 
   */

run: async (client, interaction) => {
    interaction.reply({
        embeds: [new EmbedBuilder()
        .setColor(client.embedColor)
        .setTitle(`Uptime`)
        .setDescription(`\`\`\`css\n${duration(client.uptime).map(i=> `${i}`).join(`︲`)}\`\`\``)
        .setImage(`https://cdn.discordapp.com/attachments/925414156029538375/992463049602637855/Uptime.png`)
        .setFooter({text: 'Powered by hydra-hosting.eu'})
    ]
        });
    },
};