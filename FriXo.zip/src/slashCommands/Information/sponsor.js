const { EmbedBuilder, CommandInteraction, Client, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'sponsor',
    description: 'Gives you information Lara Sponsor',
    userPrams: [],
    botPrams: ['EmbedLinks'],

    /**
   *
   * @param {Client} client
   * @param {CommandInteraction} interaction
   */

    run: async (client, interaction) => {
        let bu1 = new ButtonBuilder()
        .setStyle(ButtonStyle.Link)
        .setURL(`https://crvt.co/b`)
        .setLabel('Free discord graphics')
        .setEmoji(`<:creaviteco:940448420366266388>`)
        
        let bu2 = new ButtonBuilder()
        .setStyle(ButtonStyle.Link)
        .setURL(`https://discord.gg/hJYju2ncSQ`)
        .setLabel('Discord')
        .setEmoji(`<:Discord:940453845375516762>`)

        let row = new ActionRowBuilder().addComponents([bu1], [bu2]);
        let ping = new EmbedBuilder()
        .setColor(client.embedColor)
        .setTitle('auto.creavite.co')
        .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL({dynamic: true})})
        .setDescription(`Creavite Is Best For Making Discord Icons , Discord Profile Banners , Animated Banners And Lot More Click Above Buttons For Go To Their Website Or Join Their Discord.`)
        .setFooter({text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL({dynamic: true})})
        .setImage(`https://api.creavite.co/marketing/banner.gif`)
        
        interaction.reply({embeds: [ping], components: [row]});
    },
};
