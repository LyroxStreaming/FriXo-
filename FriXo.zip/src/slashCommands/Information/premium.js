const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
name: 'premium',
description: 'Show all info about lara premium!',
userPrams: [],
botPrams: ['EmbedLinks'],

    run: async (client, interaction) => {
        let user = client.user
        let button_support_dc = new ButtonBuilder()
        .setEmoji("<:plus:927525489445318746>")
        .setStyle(ButtonStyle.Link)
        .setLabel('Support Server')
        .setURL("https://discord.gg/xcjZqS9nJY")
    
        let button_invite = new ButtonBuilder()
        .setEmoji("<:links:927525488681971722>")
        .setStyle(ButtonStyle.Link)
        .setLabel("Invite " + user.username)
        .setURL(`https://discord.com/api/oauth2/authorize?client_id=${user.id}&permissions=8&scope=bot%20applications.commands`)
        
        let butweb = new ButtonBuilder()
        .setEmoji(`<:filters2:950441619444879371>`)
        .setStyle(ButtonStyle.Link)
        .setLabel(`Website`)
        .setURL(`https://larabot.tk`)
    
        const allbuttons = [new ActionRowBuilder().addComponents([button_support_dc, button_invite, butweb])];

        interaction.reply({
            embeds: [new EmbedBuilder()
                .setColor(client.embedColor)
                .setTitle('Lara✨ Premium')
                .setDescription(`**You want to get Lara premium join support server and read [this](https://discord.com/channels/924888533137764403/1033363849581174794)**`)
                .setImage('https://cdn.discordapp.com/attachments/925414156029538375/1033019331015090277/Premium.png')
                .setFooter({text: 'Powered by hydra-hosting.eu'})
            ],
            components: allbuttons,
            ephemeral: true});
    },
};
