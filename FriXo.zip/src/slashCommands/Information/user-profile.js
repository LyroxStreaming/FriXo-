const { EmbedBuilder, CommandInteraction, Client, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const db = require('../../schema/user');

module.exports = {
    name: 'user-profile',
    description: 'premium user profile info',
    userPrams: [],
    botPrams: ['EmbedLinks'],

    /**
   *
   * @param {Client} client
   * @param {CommandInteraction} interaction
   */

    run: async (client, interaction) => {
        let user = await db.findOne({ Id: interaction.member.id });

        if(user) {
        let redeemtime= user.redeemedAt.toString().split("");
            redeemtime.pop();
            redeemtime.pop();
            redeemtime.pop();
            redeemtime = redeemtime.join("");

        let expiretime= user.expireTime.toString().split("");
            expiretime.pop();
            expiretime.pop();
            expiretime.pop();
            expiretime = expiretime.join("");

        let userembed = new EmbedBuilder()
        .setColor(client.embedColor)
        .setTitle(`Lara✨ Premium User`)
        .setDescription(`
        **Plan Redeemed By - <@${user.redeemedBy}>**
        **Plan - ${user.plan}**
        **Plan Redeemed At - <t:${redeemtime}>(<t:${redeemtime}:R>)**
        **Plan Expiretime - <t:${expiretime}>(<t:${expiretime}:R>)**
        `)
        .setImage('https://cdn.discordapp.com/attachments/925414156029538375/1033019331015090277/Premium.png')

        interaction.reply({embeds: [userembed]})

        } else {
            let premium = new ButtonBuilder()
            .setEmoji("<:stars1:927525489558581258>")
            .setStyle(ButtonStyle.Secondary)
            .setCustomId('premium')
            .setLabel('Premium')

        const row = new ActionRowBuilder().addComponents([premium]);
        let nouserembed = new EmbedBuilder()
            .setColor(client.embedColor)
            .setTitle(`Lara✨ Premium`)
            .setDescription(`**You are not premium user, if you want to be premium user click the button**`)
            .setImage('https://cdn.discordapp.com/attachments/925414156029538375/1033019331493249095/Premium_Required.png')

        interaction.reply({embeds: [nouserembed], components: [row]});
        };
    },
};
