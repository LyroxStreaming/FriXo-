const { EmbedBuilder, CommandInteraction, Client } = require('discord.js');

module.exports = {
  name: 'join',
  description: 'Join voice channel',
  userPrams: [],
  botPrams: ['EmbedLinks'],
  player: false,
  inVoiceChannel: true,
  sameVoiceChannel: true,
  /**
   *
   * @param {Client} client
   * @param {CommandInteraction} interaction
   */

  run: async (client, interaction) => {
      let player =await client.poru.createConnection({
        guildId: interaction.guild.id,
        voiceChannel: interaction.member.voice.channel.id,
        textChannel: interaction.channel.id,
        selfDeaf: true,
      });
      player.setVolume(0.7);
    
    if (player) {
      return await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.embedColor)
            .setDescription(`<:no:927525488644194345> **I'm already connected to <#${player.voiceChannel}> voice channel!**`)
            .setFooter({text: 'Powered by hydra-hosting.eu'}),
        ],
      });
    } else {
      let thing = new EmbedBuilder()
        .setColor(client.embedColor)
        .setTitle(`<:yes:927525490443571261> **Joined and connected to your Talk!**`)
        .setFooter({text: 'Powered by hydra-hosting.eu'});
      return interaction.reply({ embeds: [thing] });
    };
  },
};
