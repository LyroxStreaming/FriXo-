const { EmbedBuilder, CommandInteraction, Client } = require('discord.js');

module.exports = {
  name: 'stop',
  description: 'Stops the music',
  userPrams: [],
  botPrams: ['EmbedLinks'],
  player: true,
  dj: true,
  inVoiceChannel: true,
  sameVoiceChannel: true,
  activeplayer: true,
  /**
   *
   * @param {Client} client
   * @param {CommandInteraction} interaction
   */

  run: async (client, interaction, player) => {
    player.destroy();
    
    let stop = new EmbedBuilder()
      .setColor(client.embedColor)
      .setTitle(`<:yes:927525490443571261> **Stopped playing**`)
      .setFooter({text: 'Powered by hydra-hosting.eu'});
    interaction.reply({ embeds: [stop] });
  },
};
