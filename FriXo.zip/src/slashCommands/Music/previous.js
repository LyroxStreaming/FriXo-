const { EmbedBuilder, CommandInteraction, Client } = require('discord.js');
const { editlastmsg } = require('../../utils/functions');

module.exports = {
    name: 'previous',
    description: 'Play the previous song lara played in your server',
    userPrams: [],
    botPrams: ['EmbedLinks'],
    player: true,
    inVoiceChannel: false,
    sameVoiceChannel: false,
    activeplayer: false,
    /**
   *
   * @param {Client} client
   * @param {CommandInteraction} interaction
   */

    run: async (client, interaction, player) => {
        let song = player.previousTrack;
        if(!song) {
            interaction.reply({
            embeds: [new EmbedBuilder()
                .setColor(client.embedColor)
                .setTitle("<:no:927525488644194345> No previous song found")
                .setFooter({text: 'Powered by hydra-hosting.eu'})
            ],
            ephemeral: true
            });
        }
        if(song){
            player.queue.add(song);
            player.stop();
            player.play();
            editlastmsg(client, player);
            interaction.reply({
            embeds: [new EmbedBuilder()
                .setColor(client.embedColor)
                .setTitle("<:yes:927525490443571261> Skiped to previous song")
                .setFooter({text: 'Powered by hydra-hosting.eu'})
            ],
            ephemeral: true
            });
        };
    },
};
