const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'removenode',
    category: 'Owner',
    description: 'remove voice server from lara',
    args: false,
    permission: [],
    owner: true,
    execute: async (message, args, client, prefix) => {

    },
};