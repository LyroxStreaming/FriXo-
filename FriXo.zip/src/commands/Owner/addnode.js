const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'addnode',
    category: 'Owner',
    description: 'Add voice server to lara',
    args: false,
    permission: [],
    owner: true,
    execute: async (message, args, client, prefix) => {

    },
};