const { EmbedBuilder, ActionRowBuilder, SelectMenuBuilder } = require('discord.js');

module.exports = {
  name: 'help',
  category: 'Information',
  aliases: ['h'],
  description: 'lara all commands',
  args: false,
  usage: '',
  userPrams: [],
  botPrams: ['EmbedLinks'],
  owner: false,
  execute: async (message, args, client, prefix) => {
    const embed = new EmbedBuilder()
      .setColor(client.embedColor)
      .setFooter({text: `Thanks For Choosing Lara✨!`, iconURL: client.user.displayAvatarURL()})
      .setAuthor({name: `Lara✨ Help Panel`, iconURL: client.user.displayAvatarURL({dynamic: true})})
      .addFields([
        {name: '<:fast:927525488203816960> **__How to play music__**', value: `\`/play <track_name/url>\``},
        {name: '<:qustion:968366638795730994> __What Is Lara__', value: `A Next Gen Discord Music Bot With Many Awesome Features, Buttons, Menus, Context Menu, Support Many Sources, Customizable Settings.`},
        {name: '<:commands:944941505003536434> **__Command Categories:__**', value: `<:infos:927525488577114152> \`:\` **Info Commands**
        <:music:927525488866521138> \`:\` **Music Commands**
        <:filters2:950441619444879371> \`:\` **Filter Commands**
        <:settings:927525490250633306> \`:\` **Settings Commands**
        <:commands:944941505003536434> \`:\` **CustomPlaylist Commands**
        <:owner:927525489093005382> \`:\` **Owner Commands**
        <:creaviteco:940448420366266388> \`:\` **Free Discord Graphics**`}
      ])
      .setImage(`https://cdn.discordapp.com/attachments/925414156029538375/992462601529344110/Lara.png`)
      
    const row = new ActionRowBuilder().addComponents(
      new SelectMenuBuilder()
        .setCustomId('larahelp')
        .setMinValues(1)
        .setMaxValues(1)
        .setPlaceholder('🎧 | Select to view the commands')
        .addOptions([
          {
            label: "Information",
            value: "Information",
            emoji: "927525488577114152",
          },
          {
            label: "Music",
            value: "Music",
            emoji: "927525488866521138",
          },
          {
            label: "Filter",
            value: "Filter",
            emoji: "950441619444879371",
          },
          {
            label: "Customplaylist",
            value: "Customplaylist",
            emoji: "944941505003536434",
          },
          {
            label: "Settings",
            value: "Settings",
            emoji: "927525490250633306",
          },
          {
            label: "Owner",
            value: "Owner",
            emoji: "927525489093005382",
          },
          {
            label: "Free Discord Graphics",
            value: "Sponsor",
            emoji: "940448420366266388",
          },
        ]),
    );

    await message.reply({ embeds: [embed], components: [row] });
  },
};