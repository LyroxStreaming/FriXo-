const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'vote',
    category: 'Information',
    description: 'vote info of lara',
    args: false,
    usage: '',
    userPrams: [],
    botPrams: ['EmbedLinks'],
    owner: false,
    execute: async (message, args, client, prefix) => {

        let button_support_dc = new ButtonBuilder()
        .setEmoji("<:plus:927525489445318746>")
        .setStyle(ButtonStyle.Link)
        .setLabel('Support Server')
        .setURL("https://discord.gg/xcjZqS9nJY")

        let button_invite = new ButtonBuilder()
        .setEmoji("<:links:927525488681971722>")
        .setStyle(ButtonStyle.Link)
        .setLabel("Vote Site 1")
        .setURL(`https://discordbotlist.com/bots/lara/upvote`)
        
        let butweb = new ButtonBuilder()
        .setEmoji(`<:links:927525488681971722>>`)
        .setStyle(ButtonStyle.Link)
        .setLabel(`Vote Site 2`)
        .setURL(`https://top.gg/bot/944016826751389717/vote`)

        const allbuttons = [new ActionRowBuilder().addComponents([button_support_dc, button_invite, butweb])];

        let ping = new EmbedBuilder()
        .setColor(client.embedColor)
        .setTitle(`Lara✨`)
        .setDescription(`
        <:fast:927525488203816960> **Site 1 - Discordbotlist.com**
        <:fast:927525488203816960> **Site 2 - Top.gg**`)
        .setImage(`https://cdn.discordapp.com/attachments/925414156029538375/992463049808154734/vote.png`)
        .setFooter({text: `${message.guild.name}`, iconURL: message.guild.iconURL({dynamic: true})})
        message.channel.send({embeds: [ping], components: allbuttons});
    },
};
