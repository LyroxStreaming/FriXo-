const { EmbedBuilder, WebhookClient } = require('discord.js');
const web = new WebhookClient({ url: 'https://discord.com/api/webhooks/1032952369610227764/BDB_rQ5Cs5uyEfXULyc9mKzFV5c_J4wEBZ2exPvWMfBAhjCCtta_dk6V_4WwveOdzIrJ' });
const schema = require('../../schema/code');
const User = require('../../schema/user');

module.exports = {
    name: "redeem",
    category: "Information",
    description: "Redeem Premium codes",
    args: false,
    permission: [],
    execute: async (message, args, client, prefix) => {
        let code = args[0]
        let user = await User.findOne({Id: message.author.id});
        if (!code)
        return message.channel.send({
            embeds: [
                new EmbedBuilder()
                .setColor(client.embedColor)
                .setDescription(`<:no:927525488644194345> **Please specify the code you want to redeem!**`),
            ],
        });

        const Pcode = await schema.findOne({
            code: code.toUpperCase(),
        });
        if(!Pcode) { 
            return message.channel.send({
            embeds: [
                new EmbedBuilder()
                .setColor(client.embedColor)
                .setDescription(`<:no:927525488644194345> **The code is invalid. Please try again using valid one!**`),
            ],
            });
        };
        if (Pcode && user) {
        user.expireTime = user.expireTime + Pcode.times;
        let time = user.expireTime.toString().split("");
            time.pop();
            time.pop();
            time.pop();
            time = time.join("");
        
        user.isPremium = true
        user.redeemedBy = message.author.id
        user.redeemedAt = Date.now()
        user.plan = Pcode.plan,
        user.expireAt = user.expireTime,
        user.expireTime = user.expireTime

        user = await user.save({ new: true });
        await Pcode.deleteOne();

        let userembed = new EmbedBuilder()
        .setTitle('Lara✨ Premium')
        .setDescription(
            `<:yes:927525490443571261> **You have successfully redeemed Lara✨ Premium!**

            **Redeemed By - <@${message.author.id}>**
            **Plan - ${Pcode.plan}**
            Expires at: <t:${time}>(<t:${time}:R>)`)
        .setImage('https://cdn.discordapp.com/attachments/925414156029538375/1033019331015090277/Premium.png')
        .setColor(client.embedColor)

        message.channel.send({ embeds: [userembed] });
        web.send({embeds: [userembed]});
        } 
            else if(Pcode && !user) {
            let time = Pcode.expireTime.toString().split("");
                time.pop();
                time.pop();
                time.pop();
                time = time.join("");

            await User.create({
                Id: message.author.id,
                isPremium: true,
                redeemedBy : message.author.id,
                redeemedAt : Date.now(),
                plan: Pcode.plan,
                expireAt : Pcode.expireTime,
                expireTime: Pcode.expireTime
            });
            await Pcode.deleteOne().catch(() => {});
            let userembed = new EmbedBuilder()
            .setTitle('Lara✨ Premium')
            .setDescription(
                `<:yes:927525490443571261> **You have successfully redeemed Lara✨ Premium!**

                **Redeemed By - <@${message.author.id}>**
                **Plan - ${Pcode.plan}**
                Expires at: <t:${time}>(<t:${time}:R>)`)
            .setImage('https://cdn.discordapp.com/attachments/925414156029538375/1033019331015090277/Premium.png')
            .setColor(client.embedColor)
                message.channel.send({ embeds: [userembed] });
                web.send({embeds: [userembed]});
            };
    },
};