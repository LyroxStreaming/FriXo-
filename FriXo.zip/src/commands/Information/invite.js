const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');

module.exports = {
  name: 'invite',
  category: 'Information',
  aliases: ['addme'],
  description: 'invite of lara',
  args: false,
  usage: '',
  userPrams: [],
  botPrams: ['EmbedLinks'],
  owner: false,
  execute: async (message, args, client, prefix) => {
    let button_support_dc = new ButtonBuilder()
    .setEmoji('<:plus:927525489445318746>')
    .setStyle(ButtonStyle.Link)
    .setLabel(`Support Server`)
    .setURL("https://discord.gg/xcjZqS9nJY")

    let button_invite = new ButtonBuilder()
    .setEmoji("<:links:927525488681971722>")
    .setStyle(ButtonStyle.Link)
    .setLabel("Invite  Lara✨")
    .setURL(`https://discord.com/api/oauth2/authorize?client_id=944016826751389717&permissions=8&scope=bot%20applications.commands`)
    
    let butweb = new ButtonBuilder()
    .setEmoji(`<:filters2:950441619444879371>`)
    .setStyle(ButtonStyle.Link)
    .setLabel(`Website`)
    .setURL(`https://larabot.tk`)

  const allbuttons = [new ActionRowBuilder().addComponents([button_support_dc, button_invite, butweb])];
  message.reply({
    embeds: [new EmbedBuilder()
      .setColor(client.embedColor)
        .setTitle(`Invite: __**Lara✨#9577**__`)
        .setDescription(`
        __**What we provide**__`)
        .setImage(`https://cdn.discordapp.com/attachments/925414156029538375/992462601239932978/Invite.png`)
        .setURL(`https://discord.com/api/oauth2/authorize?client_id=944016826751389717&permissions=8&scope=bot%20applications.commands`)
        .setFooter({text: "Lara✨#9577"})
    ],
    components: allbuttons
  });
  },
};
