const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  name: 'support',
  category: 'Information',
  aliases: [],
  description: 'Gives you the link of my support server',
  args: false,
  usage: '',
  userPrams: [],
  botPrams: ['EmbedLinks'],
  owner: false,
  execute: async (message, args, client, prefix) => {
    let user = client.user
    let button_support_dc = new ButtonBuilder()
    .setEmoji("<:plus:927525489445318746>")
    .setStyle(ButtonStyle.Link)
    .setLabel('Support Server')
    .setURL("https://discord.gg/xcjZqS9nJY")

    let button_invite = new ButtonBuilder()
    .setEmoji("<:links:927525488681971722>")
    .setStyle(ButtonStyle.Link)
    .setLabel("Invite " + user.username)
    .setURL(`https://discord.com/api/oauth2/authorize?client_id=${user.id}&permissions=8&scope=bot%20applications.commands`)
    
    let butweb = new ButtonBuilder()
    .setEmoji(`<:filters2:950441619444879371>`)
    .setStyle(ButtonStyle.Link)
    .setLabel(`Website`)
    .setURL(`https://larabot.tk`)

    const allbuttons = [new ActionRowBuilder().addComponents([button_support_dc, button_invite, butweb])];
    message.reply({
    embeds: [new EmbedBuilder()
    .setColor(client.embedColor)
    .setDescription(`
    __**What we provide**__
    Join support server to get help`)
    .setImage(`https://cdn.discordapp.com/attachments/925414156029538375/992463049350987886/Support.png`)
    .setFooter({text: 'Powered by hydra-hosting.eu'})
    ],
    components: allbuttons 
    });
  },
};
