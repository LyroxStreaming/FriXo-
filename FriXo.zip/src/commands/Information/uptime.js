const { EmbedBuilder } = require('discord.js');
const { duration } = require('../../utils/functions');

module.exports = {
    name: 'uptime',
    category: 'Information',
    description: 'Lara uptime',
    args: false,
    usage: '',
    userPrams: [],
    botPrams: ['EmbedLinks'],
    owner: false,
    execute: async (message, args, client, prefix) => {
        message.reply({
            embeds: [new EmbedBuilder()
            .setColor(client.embedColor)
            .setTitle(`Uptime`)
            .setDescription(`\`\`\`css\n${duration(client.uptime).map(i=> `${i}`).join(`︲`)}\`\`\``)
            .setImage(`https://cdn.discordapp.com/attachments/925414156029538375/992463049602637855/Uptime.png`)
            .setFooter({text: 'Powered by hydra-hosting.eu'})
        ]
        });
    },
};
