const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'sponsor',
    category: 'Information',
    aliases: [],
    description: 'Gives you information Lara Sponsor',
    args: false,
    usage: '',
    userPrams: [],
    botPrams: ['EmbedLinks'],
    owner: false,
    execute: async (message, args, client, prefix) => {
        let bu1 = new ButtonBuilder()
        .setStyle(ButtonStyle.Link)
        .setURL(`https://crvt.co/b`)
        .setLabel('Free discord graphics')
        .setEmoji(`<:creaviteco:940448420366266388>`)
        
        let bu2 = new ButtonBuilder()
        .setStyle(ButtonStyle.Link)
        .setURL(`https://discord.gg/hJYju2ncSQ`)
        .setLabel('Discord')
        .setEmoji(`<:Discord:940453845375516762>`)

        let row = new ActionRowBuilder().addComponents([bu1], [bu2]);
        let ping = new EmbedBuilder()
        .setColor(client.embedColor)
        .setTitle('auto.creavite.co')
        .setAuthor({ name: message.author.username, iconURL: message.author.displayAvatarURL({dynamic: true})})
        .setDescription(`Creavite Is Best For Making Discord Icons , Discord Profile Banners , Animated Banners And Lot More Click Above Buttons For Go To Their Website Or Join Their Discord.`)
        .setFooter({text: `${message.guild.name}`, iconURL: message.guild.iconURL({dynamic: true})})
        .setImage(`https://api.creavite.co/marketing/banner.gif`)
        
        message.reply({embeds: [ping], components: [row]});
    },
};
