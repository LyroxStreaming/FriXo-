const { EmbedBuilder } = require('discord.js');
const { editlastmsg } = require('../../utils/functions.js');

module.exports = {
  name: 'previous',
  aliases: ['pv'],
  category: 'Music',
  description: 'Play the previous song lara played in your server',
  args: false,
  usage: '',
  userPrams: [],
  botPrams: ['EmbedLinks'],
  owner: false,
  player: true,
  inVoiceChannel: false,
  sameVoiceChannel: false,
  activeplayer: false,
  execute: async (message, args, client, prefix, player) => {
    let song = player.previousTrack;
    if(!song) {
      message.reply({
        embeds: [new EmbedBuilder()
            .setColor(client.embedColor)
            .setTitle("<:no:927525488644194345> No previous song found")
            .setFooter({text: 'Powered by hydra-hosting.eu'})
        ],
        });
    };
    if(song){
      player.queue.add(song);
      player.stop();
      player.play();
      editlastmsg(client, player);
      message.reply({
        embeds: [new EmbedBuilder()
            .setColor(client.embedColor)
            .setTitle("<:yes:927525490443571261> Skiped to previous song")
            .setFooter({text: 'Powered by hydra-hosting.eu'})
        ],
        });
    };
  },
};
