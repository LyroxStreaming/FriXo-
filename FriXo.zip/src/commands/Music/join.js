const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'join',
  aliases: ['j'],
  category: 'Music',
  description: 'Join voice channel',
  args: false,
  usage: '',
  userPrams: [],
  botPrams: ['EmbedLinks'],
  owner: false,
  player: false,
  inVoiceChannel: true,
  sameVoiceChannel: false,
  execute: async (message, args, client, prefix, player) => {
    if (player) {
      return await message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(client.embedColor)
            .setDescription(`<:no:927525488644194345> **I'm already connected to <#${player.voiceChannel}> voice channel!**`),
        ],
      });
    } else {
      await client.poru.createConnection({
        guildId: message.guild.id,
        voiceChannel: message.member.voice.channel.id,
        textChannel: message.channel.id,
        selfDeaf: true,
      });
      player.setVolume(0.7);

      let thing = new EmbedBuilder()
        .setColor(client.embedColor)
        .setTitle(`<:yes:927525490443571261> **Joined and connected to your Talk!**`)
        .setFooter({text: 'Powered by hydra-hosting.eu'})
      return message.reply({ embeds: [thing] });
    };
  },
};
