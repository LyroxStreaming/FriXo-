const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'stop',
  category: 'Music',
  description: 'Stops the music',
  args: false,
  usage: '',
  userPrams: [],
  botPrams: ['EmbedLinks'],
  dj: true,
  owner: false,
  player: true,
  inVoiceChannel: true,
  sameVoiceChannel: true,
  activeplayer: true,
  execute: async (message, args, client, prefix, player) => {
    player.destroy();

    let stop = new EmbedBuilder()
      .setColor(client.embedColor)
      .setTitle(`<:yes:927525490443571261> **Stopped playing**`)
      .setFooter({text: 'Powered by hydra-hosting.eu'});
    message.reply({ embeds: [stop] });
  },
};
