const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'loop',
  aliases: ['l'],
  category: 'Music',
  description: 'Toggle music loop',
  args: false,
  usage: '',
  userPrams: [],
  botPrams: ['EmbedLinks'],
  dj: true,
  owner: false,
  player: true,
  inVoiceChannel: true,
  sameVoiceChannel: true,
  activeplayer: true,
  vote: true,
  execute: async (message, args, client, prefix, player) => {
    if (!args[0])
    return message.reply({
      embeds: [new EmbedBuilder()
        .setColor(client.embedColor)
        .setTitle(`<:no:927525488644194345> **Please add your Looping Method!**`)
        .setDescription(`\`loop track\` / \`loop queue\` / \`loop off\``)
        .setFooter({text: 'Powered by hydra-hosting.eu'})
      ]
    });
    if (['q', 'queue'].includes(args[0])) {
      await player.setLoop('QUEUE');
      let thing = new EmbedBuilder()
        .setColor(client.embedColor)
        .setTitle(`<:yes:927525490443571261> Loop \`queue\` is now enable`);
      return message.reply({ embeds: [thing] });
    } else if (['track', 't'].includes(args[0])) {
      await player.setLoop('TRACK');

      let thing = new EmbedBuilder()
        .setColor(client.embedColor)
        .setTitle(`<:yes:927525490443571261> Loop \`track\` is now enable`);
      return message.reply({ embeds: [thing] });
    } else if (['off', 'c', 'clear'].includes(args[0])) {
      await player.setLoop('NONE');

      let thing = new EmbedBuilder()
        .setColor(client.embedColor)
        .setTitle(`<:yes:927525490443571261> Loop is now \`disabled\``);
      return message.reply({ embeds: [thing] });
    };
  },
};
