const { EmbedBuilder } = require("discord.js");

module.exports = {
    name: "leave",
    aliases: ["dc", "dis"],
    category: "Music",
    description: "Leave voice channel",
    args: false,
    usage: "",
    userPrams: [],
    botPrams: ["EmbedLinks"],
    dj: true,
    owner: false,
    player: false,
    inVoiceChannel: true,
    sameVoiceChannel: true,
    activeplayer: false,
    execute: async (message, args, client, prefix, player) => {
        await player.destroy();
        message.reply({
            embeds: [new EmbedBuilder()
            .setColor(client.embedColor)
            .setTitle(`<:yes:927525490443571261> **Left the channel**`)
            .setFooter({text: 'Powered by hydra-hosting.eu'})
        ]});
    },
};