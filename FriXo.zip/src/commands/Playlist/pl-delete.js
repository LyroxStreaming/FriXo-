const { EmbedBuilder } = require('discord.js');
const db = require('../../schema/playlist');

module.exports = {
    name: 'pl-delete',
    aliases: ['pldelete'],
    category: 'Playlist',
    description: 'Delete your saved playlist.',
    args: false,
    usage: '<playlist name>',
    userPrams: [],
    botPrams: ['EmbedLinks'],
    owner: false,
    player: false,
    inVoiceChannel: false,
    sameVoiceChannel: false,
    vote: true,
    execute: async (message, args, client, prefix, player) => {
    const Name = args[0];
        const data = await db.findOne({ UserId: message.author.id, PlaylistName: Name });
        if (!Name) {
            return message.reply({ embeds: [new EmbedBuilder()
                .setColor(client.embedColor)
                .setDescription(`<:no:927525488644194345> You didn't entered a playlist name\nUsage: \`${prefix}pl-delete <playlist name>\`\nName Information:\n\`Can be anything with maximum of 10 Letters\``)
                .setFooter({text: 'Powered by hydra-hosting.eu'})]});
        };
        if (!data) {
            return message.reply({ embeds: [new EmbedBuilder()
                .setColor(client.embedColor)
                .setTitle(`<:no:927525488644194345> You don't have a playlist with \`${Name}\` name`)
                .setFooter({text: 'Powered by hydra-hosting.eu'})]});
        };
        await data.delete();
        const embed = new EmbedBuilder()
            .setColor(client.embedColor)
            .setTitle(`<:yes:927525490443571261> Successfully deleted \`${Name}\` playlist`)
            .setFooter({text: 'Powered by hydra-hosting.eu'});
        return message.channel.send({ embeds: [embed] });
    },
};
