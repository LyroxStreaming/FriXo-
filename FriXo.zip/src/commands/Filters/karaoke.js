const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: 'karaoke',
  category: 'Filters',
  aliases: ['distort'],
  description: 'Set Karaoke Filter',
  args: false,
  usage: '',
  userPrams: [],
  botPrams: ['EmbedLinks'],
  owner: false,
  player: true,
  dj: true,
  inVoiceChannel: true,
  sameVoiceChannel: true,
  activeplayer: true,
  execute: async (message, args, client, prefix, player) => {
    player.filters.setFilters({
      op: 'filters',
      guildId: message.guild.id,
      rotation: { rotationHz: 0.2 },
    });
    return message.channel.send({
      embeds: [new EmbedBuilder()
        .setColor(client.embedColor)
        .setTitle(`<:yes:927525490443571261> Applying the \`KARAOKE\` Filter`)
        .setFooter({text: 'Powered by hydra-hosting.eu'})
      ]
    });
  },
};
