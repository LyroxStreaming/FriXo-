const { EmbedBuilder } = require("discord.js");
const db = require("../../schema/dj");

module.exports = {
    name: "removedj",
    category: 'Settings',
    description: "Remove Dj Role",
    args: false,
    usage: "",
    aliases: ["romdj"],
    userPrams: ['ManageGuild'],
    botPrams: ['ManageGuild'],
    owner: false,
    vote: true,
    execute: async (message, args, client, prefix, player) => {
        let data = await db.findOne({ Guild: message.guild.id });
        if (data) {
            await data.delete()
            return message.reply({ embeds: [new EmbedBuilder()
                .setTitle(`<:yes:927525490443571261> Successfully Removed All DJ Roles.`)
                .setColor(client.embedColor)
                .setFooter({text: 'Powered by hydra-hosting.eu'})] });

        } else return message.reply({ embeds: [new EmbedBuilder()
            .setTitle(`<:no:927525488644194345> Don't Have Dj Setup In This Guild`)
            .setColor(client.embedColor)
            .setFooter({text: 'Powered by hydra-hosting.eu'})] });
    },
};
