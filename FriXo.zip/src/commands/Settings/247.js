const { EmbedBuilder } = require('discord.js');
const db = require("../../schema/autoReconnect");

module.exports = {
    name: '247',
    category: 'Settings',
    description: 'Set 24/7 system',
    args: false,
    userPrams: [],
    botPrams: ['EmbedLinks'],
    dj: true,
    inVoiceChannel: true,
    sameVoiceChannel: true,
    vote: true,
    execute: async (message, args, client, prefix) => {

        const player = await client.poru.createConnection({
            guildId: message.guild.id,
            voiceChannel: message.member.voice.channel.id,
            textChannel: message.channel.id,
            selfDeaf: true,
        });

        let data = await db.findOne({Guild: message.guild.id});
        if (data) {
            await data.delete();
            let thing = new EmbedBuilder()
            .setTitle(`Lara 24/7 System`)
            .setColor(client.embedColor)
            .setDescription(`<:yes:927525490443571261> 24/7 System Has Been Removed If You Like Lara Vote Me`)
            .setImage("https://cdn.discordapp.com/attachments/925414156029538375/992462599486705754/247.png")
            .setFooter({text: 'Powered by hydra-hosting.eu'});
            message.reply({ embeds: [thing] })
        } else {
            data = new db({
                Guild: player.guildId,
                TextId: player.textChannel,
                VoiceId: player.voiceChannel
            });
            await data.save();
            let thing = new EmbedBuilder()
            .setColor(client.embedColor)
            .setTitle(`Lara 24/7 System`)
            .setDescription(`<:yes:927525490443571261> 24/7 System Has Been Setup If You Like Lara Vote Me`)
            .setImage("https://cdn.discordapp.com/attachments/925414156029538375/992462599486705754/247.png")
            .setFooter({text: 'Powered by hydra-hosting.eu'});
            message.reply({ embeds: [thing] })
        };
    },
};
