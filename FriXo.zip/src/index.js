const MusicBot = require("./structures/Client");
const client = new MusicBot();
module.exports = client; 
client.connect();

