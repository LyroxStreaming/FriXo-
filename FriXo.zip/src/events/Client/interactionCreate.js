const { EmbedBuilder, PermissionsBitField, ActionRowBuilder, ButtonBuilder, Collection, ButtonStyle, InteractionType, CommandInteraction } = require('discord.js');
const { IsVoted, editbutton } = require("../../utils/functions");
const db2 = require("../../schema/dj");
const db5 = require('../../schema/user');
const db6 = require('../../schema/server');
const db7 = require('../../schema/vote');
const { makeUri } = require('../../utils/makeurl');
  /**
   * @param {CommandInteraction} interaction
   */

module.exports = {
  name: 'interactionCreate',
  run: async (client, interaction) => {
    if (interaction.type === InteractionType.ApplicationCommand) {
      const { guild } = interaction;
        if (!guild) {
          return interaction.reply({
            embeds: [new EmbedBuilder()
              .setColor(client.embedColor)
              .setDescription(`<:no:927525488644194345> Interactions is only work inside a guild!`)],
            ephemeral: true
          }).catch(() => {});
        }
      const SlashCommands = client.slashCommands.get(interaction.commandName);
      if (!SlashCommands) return;

      if(!interaction.channel.permissionsFor(interaction.guild.members.me).has(PermissionsBitField.resolve('ViewChannel'))) return;
      if (!interaction.channel.permissionsFor(interaction.guild.members.me).has(PermissionsBitField.resolve('SendMessages')) || !interaction.channel.permissionsFor(interaction.guild.members.me).has(PermissionsBitField.resolve('SendMessagesInThreads'))) return;
      if (!interaction.channel.permissionsFor(interaction.guild.members.me).has(PermissionsBitField.resolve('ReadMessageHistory')))
        return interaction.channel.send(`<:no:927525488644194345> I don't have \`ReadMessageHistory\` permission to execute this command!`);
      if (!interaction.guild.members.me.permissions.has(PermissionsBitField.resolve('ReadMessageHistory')))
        return interaction.channel.send(`<:no:927525488644194345> I don't have \`ReadMessageHistory\` permission to execute this command!`);

      if (!interaction.guild.members.me.permissions.has(PermissionsBitField.resolve('UseExternalEmojis')))
        return interaction.reply(`<:no:927525488644194345> I don't have \`UseExternalEmojis\` permission to execute this command!`);
      if (!interaction.channel.permissionsFor(interaction.guild.members.me).has(PermissionsBitField.resolve('UseExternalEmojis')))
        return interaction.reply(`<:no:927525488644194345> I don't have \`UseExternalEmojis\` permission to execute this command!`);
      if (!interaction.guild.members.me.permissions.has(PermissionsBitField.resolve('EmbedLinks')))
        return interaction.reply(`<:no:927525488644194345> I don't have \`EmbedLinks\` permission to execute this command!`);
      if (!interaction.channel.permissionsFor(interaction.guild.members.me).has(PermissionsBitField.resolve('EmbedLinks')))
        return interaction.reply(`<:no:927525488644194345> I don't have \`EmbedLinks\` permission to execute this command!`);
      
        if (!interaction.guild.members.me.permissions.has(PermissionsBitField.resolve(SlashCommands.botPrams || []))) {
          return interaction.reply({ embeds: [new EmbedBuilder()
            .setColor(client.embedColor)
            .setTitle("<:no:927525488644194345> You are not allowed to run this command!")
            .setDescription(`<:no:927525488644194345>  I need this \`${SlashCommands.botPrams.join(', ')}\` permission use this command.`)
          ],
            ephemeral: true
          });
        };
        if (!interaction.member.permissions.has(PermissionsBitField.resolve(SlashCommands.userPrams || []))) {
          return await interaction.reply({ embeds: [new EmbedBuilder()
            .setColor(client.embedColor)
            .setTitle("<:no:927525488644194345> You are not allowed to run this command!")
            .setDescription(`<:no:927525488644194345>  You need to this \`${SlashCommands.userPrams.join(', ')}\` permission use this command.`)
          ],
            ephemeral: true
          });
        };
        
        if (SlashCommands.vote) {
          let userid = await db5.findOne({ Id: interaction.member.id });
          let serverid = await db6.findOne({ Id: interaction.guildId });
          let premium = userid || serverid;
          let votes = await db7.findOne({ Id: interaction.member.id });
          if(!votes && !premium) return IsVoted(client, interaction, interaction.member, true)
        };

        if (!client.cooldowns.has(SlashCommands)) { 
          client.cooldowns.set(SlashCommands, new Collection());
        };
        const now = Date.now(); 
        const timestamps = client.cooldowns.get(SlashCommands); 
        const cooldownAmount = (SlashCommands.cooldown || 2) * 1000;
        if (timestamps.has(interaction.member.id)) { 
          let expirationTime = timestamps.get(interaction.member.id) + cooldownAmount; 
          if (now < expirationTime) { 
            let timeLeft = (expirationTime - now) / 1000; 
            if (timeLeft < 1) timeLeft = Math.round(timeLeft)
            if (timeLeft && timeLeft != 0) {
              return interaction.reply({
                embeds: [new EmbedBuilder()
                  .setColor(client.embedColor)
                  .setTitle(`<:no:927525488644194345> Please wait ${timeLeft.toFixed(1)} more second(s) before reusing the ${interaction.commandName} command.`)
                ]
              }).catch(() => {})
            };
          };
        };
        timestamps.set(interaction.member.id, now);
        setTimeout(() => timestamps.delete(interaction.member.id), cooldownAmount);

        const player = client.poru.players.get(interaction.guild.id);
      
      if (SlashCommands.player && !player) {
        return await interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor(client.embedColor)
            .setTitle("<:no:927525488644194345> Player was not created")
          ],
          ephemeral: true,
        }).catch(() => { });
      };
      if (SlashCommands.activeplayer && !player.currentTrack) {
        return await interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor(client.embedColor)
            .setTitle("<:no:927525488644194345> There is nothing playing")
          ],
          ephemeral: true,
        }).catch(() => { });
      };
      
      if (SlashCommands.inVoiceChannel && !interaction.member.voice.channel) {
        return await interaction
          .reply({
            embeds: [new EmbedBuilder()
              .setColor(client.embedColor)
              .setTitle("<:no:927525488644194345> You need to join a voice channel.")
            ],
            ephemeral: true,
          }).catch(() => { });
      };
      if (SlashCommands.sameVoiceChannel) {
        if (interaction.guild.members.me.voice.channel) {
          if (interaction.guild.members.me.voice.channelId !== interaction.member.voice.channelId) {
            return await interaction
              .reply({
                embeds: [new EmbedBuilder()
                  .setColor(client.embedColor)
                  .setTitle("<:no:927525488644194345> You need to be in my voice channel")
                ],
                ephemeral: true,
              }).catch(() => { });
          };
        };
      };
      if (SlashCommands.dj) {
        let data = await db2.findOne({ Guild: interaction.guildId });
        let perm = PermissionsBitField.resolve('ManageGuild');
        if (data) {
          if (data.Mode) {
            let pass = false;
            if (data.Roles.length > 0) {
              interaction.member.roles.cache.forEach((x) => {
                let role = data.Roles.find((r) => r === x.id);
                if (role) pass = true;
              });
            };
            if (!pass && !interaction.member.permissions.has(perm)) return await interaction.reply({ embeds: [new EmbedBuilder().setColor(client.embedColor).setTitle("<:no:927525488644194345> You don't have permission or dj role to use this command")], ephemeral: true })
          };
        };
      };
      try {
        await SlashCommands.run(client, interaction, player);
      } catch (error) {
        if (interaction.replied) {
          await interaction
            .editReply({
              content: "An unexcepted error occured.",
            }).catch(() => { });
        } else {
          await interaction
            .followUp({
              ephemeral: true,
              content: "An unexcepted error occured.",
            }).catch(() => { });
        };
        console.error(error);
      };
    };
    if (interaction.isSelectMenu()) {
      if(interaction.customId === 'larahelp') {
          if(interaction.values[0] === 'Information') {
              let info = new EmbedBuilder()
              .setColor(client.embedColor)
              .setThumbnail(client.user.displayAvatarURL())
              .addFields([
                  {name: 'Categories » Information', value: `\`\`\`yml\nHere are the Information commands:\n\`\`\``, inline: true},
                  {name: `<:infos:927525488577114152> Commands Total [\`${client.commands.filter((cmd) => cmd.category === "Information").size}\`]`, value: `${client.commands.filter((cmd) => cmd.category === "Information").sort((a,b) => a.name.localeCompare(b.name)).map((cmd) => `\`${cmd.name}\``).join("︲")}`},
              ])
              .setImage("https://cdn.discordapp.com/attachments/925414156029538375/992462600967299173/information.png")
              interaction.reply({embeds: [info], ephemeral: true});
          };
          if(interaction.values[0] === 'Music') {
              let info = new EmbedBuilder()
              .setColor(client.embedColor)
              .setThumbnail(client.user.displayAvatarURL())
              .addFields([
                  {name: 'Categories » Music', value: `\`\`\`yml\nHere are the Music commands:\n\`\`\``, inline: true},
                  {name: `<:music:927525488866521138> Commands Total [\`${client.commands.filter((cmd) => cmd.category === "Music").size}\`]`, value: `${client.commands.filter((cmd) => cmd.category === "Music").sort((a,b) => a.name.localeCompare(b.name)).map((cmd) => `\`${cmd.name}\``).join("︲")}`},
              ])
              .setImage("https://cdn.discordapp.com/attachments/925414156029538375/992462598962413578/music.png")
              interaction.reply({embeds: [info], ephemeral: true});
          };
          if(interaction.values[0] === 'Filter') {
              let info = new EmbedBuilder()
              .setColor(client.embedColor)
              .setThumbnail(client.user.displayAvatarURL())
              .addFields([
                  {name: 'Categories » Filters', value: `\`\`\`yml\nHere are the Filter commands:\n\`\`\``, inline: true},
                  {name: `<:filters2:950441619444879371> Commands Total [\`${client.commands.filter((cmd) => cmd.category === "Filters").size}\`]`, value: `${client.commands.filter((cmd) => cmd.category === "Filters").sort((a,b) => a.name.localeCompare(b.name)).map((cmd) => `\`${cmd.name}\``).join("︲")}`},
              ])
              .setImage("https://cdn.discordapp.com/attachments/925414156029538375/992462600728231986/Filters.png")
              interaction.reply({embeds: [info], ephemeral: true});
          };
          if(interaction.values[0] === 'Customplaylist') {
              let info = new EmbedBuilder()
              .setColor(client.embedColor)
              .setThumbnail(client.user.displayAvatarURL())
              .addFields([
                  {name: 'Categories » Custom_Playlist', value: `\`\`\`yml\nHere are the Custom_Playlist commands:\n\`\`\``, inline: true},
                  {name: `<:commands:944941505003536434> Commands Total [\`${client.commands.filter((cmd) => cmd.category === "Playlist").size}\`]`, value: `${client.commands.filter((cmd) => cmd.category === "Playlist").sort((a,b) => a.name.localeCompare(b.name)).map((cmd) => `\`${cmd.name}\``).join("︲")}`},
              ])
              .setImage("https://cdn.discordapp.com/attachments/925414156029538375/992462600006803566/Custom_Playlist.png")
              interaction.reply({embeds: [info], ephemeral: true});
          };
          if(interaction.values[0] === 'Settings') {
              let info = new EmbedBuilder()
              .setColor(client.embedColor)
              .setThumbnail(client.user.displayAvatarURL())
              .addFields([
                  {name: 'Categories » Settings', value: `\`\`\`yml\nHere are the Settings commands:\n\`\`\``, inline: true},
                  {name: `<:settings:927525490250633306> Commands Total [\`${client.commands.filter((cmd) => cmd.category === "Settings").size}\`]`, value: `${client.commands.filter((cmd) => cmd.category === "Settings").sort((a,b) => a.name.localeCompare(b.name)).map((cmd) => `\`${cmd.name}\``).join("︲")}`},
              ])
              .setImage("https://cdn.discordapp.com/attachments/925414156029538375/992463049111900300/Settings.png")
              interaction.reply({embeds: [info], ephemeral: true});
          };
          if(interaction.values[0] === 'Owner') {
              let info = new EmbedBuilder()
              .setColor(client.embedColor)
              .setThumbnail(client.user.displayAvatarURL())
              .addFields([
                  {name: 'Categories » Owner', value: `\`\`\`yml\nHere are the Owner commands:\n\`\`\``, inline: true},
                  {name: `<:owner:927525489093005382> Commands Total [\`${client.commands.filter((cmd) => cmd.category === "Owner").size}\`]`, value: `${client.commands.filter((cmd) => cmd.category === "Owner").sort((a,b) => a.name.localeCompare(b.name)).map((cmd) => `\`${cmd.name}\``).join("︲")}`},
              ])
              .setImage("https://cdn.discordapp.com/attachments/925414156029538375/992462599214092418/Owner.png")
              interaction.reply({embeds: [info], ephemeral: true});
          };

        if(interaction.values[0] === 'Sponsor') {
          let bu1 = new ButtonBuilder()
          .setStyle(ButtonStyle.Link)
          .setURL(`https://crvt.co/b`)
          .setLabel('Free discord Graphics')
          .setEmoji(`<:creaviteco:940448420366266388>`)
        
          let bu2 = new ButtonBuilder()
          .setStyle(ButtonStyle.Link)
          .setURL(`https://discord.gg/hJYju2ncSQ`)
          .setLabel('Discord')
          .setEmoji(`<:Discord:940453845375516762>`)

          let row = new ActionRowBuilder().addComponents([bu1], [bu2]);

            let info = new EmbedBuilder()
            .setColor(client.embedColor)
            .setAuthor({name: client.user.tag, iconURL: client.user.displayAvatarURL()})
            .setTitle('auto.creavite.co')
            .setDescription(`Creavite Is Best For Making Discord Icons , Discord Profile Banners , Animated Banners And Lot More Click Above Buttons For Go To Their Website Or Join Their Discord.`)
            .setImage(`https://api.creavite.co/marketing/banner.gif`)

            interaction.reply({embeds: [info], components: [row], ephemeral: true});
        };
      };
  };
  if (interaction.isButton()) {
  let {member} = interaction;
  const {channel} = member.voice;
  const player = client.poru.players.get(interaction.guild.id);

  let buttons = interaction.customId === "vdown1" || interaction.customId === "pause2" || interaction.customId === "skip3" || interaction.customId === "songloop4" || interaction.customId === "vup5"  || interaction.customId === "shuffle6" || interaction.customId === "stop7" || interaction.customId === "autoplay8"|| interaction.customId === "back9"|| interaction.customId === "forwd10"
  if (buttons) {
      if(!player || !player.currentTrack) {
      return interaction.reply({
      embeds: [new EmbedBuilder()
          .setColor(client.embedColor)
          .setTitle("<:no:927525488644194345> There is nothing playing")],
      ephemeral: true
    });
  };
};
if (buttons) {
  if(!channel) {
  return interaction.reply({
      embeds: [new EmbedBuilder()
      .setColor(client.embedColor)
      .setTitle('<:no:927525488644194345> You need to join a voice channel.')],
      ephemeral: true
    });
  };
};
if (buttons) {
  if (interaction.guild.members.me.voice.channel) {
  if (interaction.guild.members.me.voice.channelId !== interaction.member.voice.channelId) {
  return interaction.reply({
      embeds: [new EmbedBuilder()
      .setTitle('<:no:927525488644194345> You need to be in my voice channel')
      .setColor(client.embedColor)
      ],
      ephemeral: true
      });
    };
  };
};

  if (interaction.customId === "vdown1") {
      let amount = Number(player.filters.volume) - 0.1;
      if(amount < 0) return interaction.reply({
          embeds: [new EmbedBuilder()
              .setColor(client.embedColor)
              .setTitle("<:no:927525488644194345> Cannot higher the player volume further more.")
          ],ephemeral: true});
      await player.setVolume(amount);
      interaction.reply({
          embeds: [new EmbedBuilder()
          .setColor(client.embedColor)
          .setTitle(`<:yes:927525490443571261>  Volume set to \`${amount * 100}\``)
          ],
          ephemeral: true});
      };

      //back
      if (interaction.customId === "back9") {
        let song = player.previousTrack;
        if(!song) {
          interaction.reply({
            embeds: [new EmbedBuilder()
                .setColor(client.embedColor)
                .setTitle("<:no:927525488644194345> No previous song found")
            ],
            ephemeral: true
            });
        };
        if(song){
          player.queue.add(song);
          player.stop();
          interaction.reply({
            embeds: [new EmbedBuilder()
                .setColor(client.embedColor)
                .setTitle("<:yes:927525490443571261> Skiped to previous song")
            ],
            ephemeral: true
            });
          };
        };
      //pause-resume
    if (interaction.customId === "pause2") {
      if (!player.isPlaying) {
          player.pause(false);
          interaction.deferUpdate()
      } else {
          player.pause(true);
          interaction.deferUpdate();
      };
      editbutton(client, player);
      };

      //skip
      if (interaction.customId === "skip3") {
        const track = player.currentTrack;
        let link = makeUri(`${track.info.title} By ${track.info.author}`);
            player.stop();
            interaction.reply({
            embeds: [new EmbedBuilder()
                .setDescription(`<:skips:988865012296732732> <@${member.user.id}> *Skipped ${track.info.title && track.info.uri ? `[${track.info.title}](${link})` : `${track.info.title}`}* `)
                .setColor(client.embedColor)
            ]
            });
        };

      //Songloop
      if (interaction.customId === "songloop4") {
        let userid = await db5.findOne({ Id: interaction.member.id });
        let serverid = await db6.findOne({ Id: interaction.guildId });
        let premium = userid || serverid;
        let votes = await db7.findOne({ Id: interaction.member.id });
        if(!votes && !premium) return IsVoted(client, interaction, interaction.member, true);
        
          if(player.loop === 'NONE') {
              player.setLoop('TRACK');
              return interaction.reply({
                  embeds: [new EmbedBuilder()
                  .setColor(client.embedColor)
                  .setTitle('<:yes:927525490443571261> **Enabled \`track\` Loop**')
                  ],
                  ephemeral: true
              });
          } else if(player.loop === 'TRACK') {
              player.setLoop('QUEUE');
              return interaction.reply({
                  embeds: [new EmbedBuilder()
                  .setColor(client.embedColor)
                  .setTitle('<:yes:927525490443571261> **Enabled \`queue\` Loop**')
                  ],
                  ephemeral: true
              });
          } else {
              player.setLoop('NONE');
              return interaction.reply({
                  embeds: [new EmbedBuilder()
                  .setColor(client.embedColor)
                  .setTitle('<:yes:927525490443571261> **Loop disabled**')
                  ],
                  ephemeral: true
              });
          };
      };

      //10+volumeup
      if (interaction.customId === "vup5") {
      let amount = Number(player.filters.volume) + 0.1;
      if(amount >= 1) return interaction.reply({
      embeds: [new EmbedBuilder()
          .setColor(client.embedColor)
          .setTitle("<:no:927525488644194345> Cannot higher the player volume further more.")
      ],ephemeral: true});
      await player.setVolume(amount);
      interaction.reply({
      embeds: [new EmbedBuilder()
          .setColor(client.embedColor)
          .setTitle(`<:yes:927525490443571261>  Volume set to \`${amount * 100}\``)
      ],
      ephemeral: true});
      };
      
      //Shuffle
      if (interaction.customId === "shuffle6") {
      let userid = await db5.findOne({ Id: interaction.member.id });
      let serverid = await db6.findOne({ Id: interaction.guildId });
      let premium = userid || serverid;
      let votes = await db7.findOne({ Id: interaction.member.id });
      if(!votes && !premium) return IsVoted(client, interaction, interaction.member, true);

      player.queue.shuffle();
      interaction.reply({
          embeds: [new EmbedBuilder()
          .setColor(client.embedColor)
          .setTitle(`<:retry:927525489327882240> **Shuffled ${player.queue.length} Songs!**`)
          ],
          ephemeral: true
      });
  };

      //stop
      if (interaction.customId === "stop7") {
        const track = player.currentTrack;
        let link = makeUri(`${track.info.title} By ${track.info.author}`);
        player.destroy();
        interaction.reply({
            embeds: [new EmbedBuilder()
                .setColor(client.embedColor)
                .setDescription(`<:yes:927525490443571261> <@${member.user.id}> *Stopped ${track.info.title && track.info.uri ? `[${track.info.title}](${link})` : `${track.info.title}`}* `)
            ],
            ephemeral: false
            });
        };
  
      //autoplay
      if (interaction.customId === "autoplay8") {
        let userid = await db5.findOne({ Id: interaction.member.id });
        let serverid = await db6.findOne({ Id: interaction.guildId });
        let premium = userid || serverid;
        let votes = await db7.findOne({ Id: interaction.member.id });
        if(!votes && !premium) return IsVoted(client, interaction, interaction.member, true);
          player.auto = !player.auto;
          interaction.reply({
          embeds: [new EmbedBuilder()
              .setColor(client.embedColor)
              .setTitle(`${player.auto ? '<:yes:927525490443571261>  **Enabled Autoplay**': '<:no:927525488644194345> **Disabled Autoplay**'}`)
          ],
          ephemeral: true
          });
      };

      //Forward
      if (interaction.customId === "forwd10") {
        let userid = await db5.findOne({ Id: interaction.member.id });
        let serverid = await db6.findOne({ Id: interaction.guildId });
        let premium = userid || serverid;
        let votes = await db7.findOne({ Id: interaction.member.id });
        if(!votes && !premium) return IsVoted(client, interaction, interaction.member, true);
        
          let seektime = Number(player.position) + 10 * 1000;
          if (10 <= 0) seektime = Number(player.position);
          player.seekTo(Number(seektime));
          interaction.reply({
          embeds: [new EmbedBuilder()
              .setColor(client.embedColor)
              .setTitle("<:forward10:927525488560316456> **Forwarded the song for \`10 Seconds\`!**")
          ],
          ephemeral: true
          });
      };
      if (interaction.customId === "premium") {
        let user = client.user
        let button_support_dc = new ButtonBuilder()
        .setEmoji("<:plus:927525489445318746>")
        .setStyle(ButtonStyle.Link)
        .setLabel('Support Server')
        .setURL("https://discord.gg/xcjZqS9nJY")
    
        let button_invite = new ButtonBuilder()
        .setEmoji("<:links:927525488681971722>")
        .setStyle(ButtonStyle.Link)
        .setLabel("Invite " + user.username)
        .setURL(`https://discord.com/api/oauth2/authorize?client_id=${user.id}&permissions=8&scope=bot%20applications.commands`)
        
        let butweb = new ButtonBuilder()
        .setEmoji(`<:filters2:950441619444879371>`)
        .setStyle(ButtonStyle.Link)
        .setLabel(`Website`)
        .setURL(`https://larabot.tk`)
    
        const allbuttons = [new ActionRowBuilder().addComponents([button_support_dc, button_invite, butweb])];

        interaction.reply({
            embeds: [new EmbedBuilder()
              .setColor(client.embedColor)
              .setTitle('Lara✨ Premium')
              .setDescription(`**You want to get Lara premium join support server and read [this](https://discord.com/channels/924888533137764403/1033363849581174794)**`)
              .setImage('https://cdn.discordapp.com/attachments/925414156029538375/1033019331015090277/Premium.png')
            ],
            components: allbuttons,
            ephemeral: true});
        };
  };
  if(interaction.type === InteractionType.ApplicationCommandAutocomplete) {
    const { guild } = interaction;
      if (!guild) return
    const SlashCommands = client.slashCommands.get(interaction.commandName);
    if (!SlashCommands) return;
    try {
      await SlashCommands.autocomplete(client, interaction);
    } catch (error) {
      console.log(error);
      };
    };
  },
};


