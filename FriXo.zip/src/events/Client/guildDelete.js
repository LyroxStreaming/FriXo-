const { EmbedBuilder, WebhookClient } = require('discord.js');
const web = new WebhookClient({ url: 'https://discord.com/api/webhooks/1013815602852413530/7ZZrmE0V6ZM_iFp0F9eDs2daYcZldVmLamSm0ltqS_Gl-KIBO8mebRxPDq68LLToakpy' });

module.exports = {
  name: "guildDelete",
  run: async (client, guild) => {
    if (!guild || guild.available === false) return;
    let theowner = "NO OWNER DATA! ID:";
    await guild.fetchOwner().then(({user}) => {theowner = user}).catch(() => {});

    let gds = await client.cluster.fetchClientValues('guilds.cache.size');
    const totalGuilds = gds.reduce((acc, guildCount) => acc + guildCount, 0);
    let embed = new EmbedBuilder()
      .setColor("#ff0000")
      .setTitle(`👋 Left a Guild`)
      .addFields([
        {name: "Guild Info", value: `>>> \`\`\`${guild.name} (${guild.id})\`\`\``},
        {name: "Owner Info", value: `>>> \`\`\`${theowner ? `${theowner.tag} (${theowner.id})` : `${theowner} (${guild.ownerId})`}\`\`\``},
        {name: "Member Count", value: `>>> \`\`\`${guild.memberCount}\`\`\``},
        {name: "Guilds Bot is in", value: `>>> \`\`\`${totalGuilds}\`\`\``},
      ])
      .setThumbnail(guild.iconURL({ dynamic: true }));
      web.send({embeds: [embed]});
  },
};