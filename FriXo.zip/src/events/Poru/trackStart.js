const { EmbedBuilder, Client, ButtonBuilder, ActionRowBuilder, PermissionsBitField, ButtonStyle } = require("discord.js");
const { convertTime } = require('../../utils/convert.js');
const { editlastmsg } = require("../../utils/functions.js");
const { makeUri } = require("../../utils/makeurl.js");

module.exports = {
	name: "trackStart",
	/**
	 * 
	 * @param {Client} client 
	 * @param {*} player 
	 * @param {*} track 
	 */
	run: async (client, player, track) => {
        let guild  = client.guilds.cache.get(player.guildId);
        if(!guild) return;
		let channel = guild.channels.cache.get(player.textChannel);
		if (!channel) return;
        player.auto = player.auto || false;
        if (player.beforetrack) {
            editlastmsg(client, player);
        }
        player.beforetrack = track;
		let playdata = musicpanel(client, player, track)
		if(channel.permissionsFor(guild.members.me).has(PermissionsBitField.resolve('SendMessages'))) {
		channel.send(playdata).then(msg => {
            player.currentmsg = msg.id;
        return msg;
		    });
	    };
    },
};
function musicpanel(client, player, track) {
    let link = makeUri(`${track.info.title} By ${track.info.author}`)
    let embed = new EmbedBuilder()
    .setColor(client.embedColor)
    .setAuthor({name: `MUSIC PANEL`, iconURL: `${track.info.requester ? `${track.info.requester.displayAvatarURL({dynamic: true})}`: `${client.user.displayAvatarURL({dynamic: true})}`}`, url: `${track.info.uri ? `${link}` : `https://discord.gg/xcjZqS9nJY`}}`})
    .setDescription(`<a:playing:948885058561916968>  ${track.info.title && track.info.uri ? `[\`${track.info.title}\`](${link})` : `\`${track.info.title}\``}`)
    .addFields([
		{name: "<:user:948907339778514984> Requested By", value: `${track.info.requester ? `<@${track.info.requester.id}>`:`<@${client.user.id}>`}`, inline: true},
		{name: "<:clocks:938721093617856512> Music Duration ", value: `\`${track.info.isStream ? "LIVE STREAM" : convertTime(track.info.length)}\``, inline: true},
		{name: "<:roleinfo:927525489428561951> Music Author", value: `\`${track.info.author}\``, inline: true},
	])

    let vdown = new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId('vdown1').setEmoji(`927525489940238367`).setLabel(`Down`);
    let back10 = new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId('back9').setEmoji('1009091540569837588').setLabel(`Back`);
    let pause = new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId('pause2').setEmoji(`927525488824549397`).setLabel(`Pause`);
    let skip = new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId('skip3').setEmoji('988865012296732732').setLabel(`Skip`);
    let vup = new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId('vup5').setEmoji('927525490103832607').setLabel(`Up`);
    let shuffle = new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId('shuffle6').setEmoji(`988865004696645652`).setLabel(`Shuffle`);
    let songloop = new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId('songloop4').setEmoji('927525489327882240').setLabel(`Loop`);
    let stop = new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId('stop7').setEmoji(`927525488644194345`).setLabel(`Stop`);
    let autoplay = new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId('autoplay8').setEmoji('988866323457130547').setLabel(`AutoPlay`);
    let forw10 = new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId('forwd10').setEmoji('927525488560316456').setLabel(`+10 Sec`);

    const row = new ActionRowBuilder().addComponents([vdown, back10, pause, skip, vup]);
    const row2 = new ActionRowBuilder().addComponents([shuffle, songloop, stop, autoplay, forw10]);
    return {
        embeds: [embed],
        components: [row, row2]
    };
};