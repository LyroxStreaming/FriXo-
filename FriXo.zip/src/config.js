require("dotenv").config();
const configs = require('../shard-config.json');
module.exports = {
  token: process.env.TOKEN, 
  prefix: process.env.PREFIX, 
  ownerID: process.env.OWNERID ,
  SpotifyID: process.env.SPOTIFYID, 
  SpotifySecret: process.env.SPOTIFYSECRET, 
  mongourl: process.env.MONGO_URI, 
  embedColor: process.env.COlOR,
  topg: process.env.TOPGG,
  logs: process.env.LOGS,
  clusterids: configs.clustercount,
  shardids: configs.shardcount,
  cornclusters: configs.clustercount-1,
    
  links: {
    support: process.env.SUPPORT ,
    invite: process.env.INVITE ,
    vote: process.env.VOTE ,
    bg: process.env.BG
  },

  nodes: [
      {
      host: process.env.NODE_URL1,
      port: process.env.NODE_PORT1,
      name: process.env.NODE_NAME1,
      password: process.env.NODE_AUTH1,
      secure: parseBoolean(process.env.NODE_SECURE1 || 'false'),
    }
  ],
};

function parseBoolean(value){
    if (typeof(value) === 'string'){
        value = value.trim().toLowerCase();
    }
    switch(value){
        case true:
        case "true":
            return true;
        default:
            return false;
    };
};